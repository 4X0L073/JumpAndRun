#include "BoxObstacle.h"


BoxObstacle::BoxObstacle(Game* game, int x, int y, int width, int height) 
	: GameObject(game, x, y, width, height) /*, _isInsideFrame(true)*/ {
}

void BoxObstacle::draw(Terminal& term, const Rectangle& camera) {
	
		GameObject::draw(term, camera);
		Vec2D screenCoords = upperLeft() - camera.upperLeft();
		for (int w = 0; w < width; w++)
		{
			for (int h = 0; h < height; h++)
				term.draw_text(screenCoords.x + w, screenCoords.y + h, "O");
		}
		
	
}
