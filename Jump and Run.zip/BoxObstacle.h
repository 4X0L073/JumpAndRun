#ifndef BOXOBSTACLE_H
#define BOXOBSTACLE_H
#include "Game.h"

class BoxObstacle : public GameObject
{
//private:
//	bool _isInsideFrame;
public:
	BoxObstacle(Game* game, int x, int y, int width, int height);
	virtual void draw(Terminal& term, const Rectangle& camera);
};


#endif