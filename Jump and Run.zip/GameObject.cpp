#include "GameObject.h"

GameObject::GameObject(Game* game, const Rectangle& rect)
	: Rectangle(rect.x, rect.y, rect.width, rect.height), _game(game), _isInsideFrame(true) { }


GameObject::GameObject(Game* game, int x, int y, int width, int height)
						: Rectangle(x, y, width, height), _game(game), _isInsideFrame(true) { }

void GameObject::update(float dt)
{
}

void GameObject::draw(Terminal& term, const Rectangle& camera)
{
	_isInsideFrame = left() >= camera.left();
}

bool GameObject::isInsideFrame() const
{
	return _isInsideFrame;
}

