#ifndef GAME_OBJECT_H
#define GAME_OBJECT_H

#include "Rectangle.h"
#include "Terminal.h"


class Game;

class GameObject : public Rectangle
{
protected:
	Game* _game;
	bool _isInsideFrame;
public:
	GameObject(Game* game, const Rectangle& rect);
	GameObject(Game* game, int x, int y, int width, int height);
	virtual void update(float dt);
	virtual void draw(Terminal& term, const Rectangle& camera);
	virtual bool isInsideFrame() const;
};

#endif // !GAME_OBJECT_H
 